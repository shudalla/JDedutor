/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Persistencia.Lexico;

import java.util.Enumeration;

/**
 *
 * @author Shu
 */
public enum Token{
    SIMBOLO,
    PARENTESES_ABRE,
    PARENTESES_FECHA,
    SE,
    SE_SOMENTE,
    ELOGICO,
    OULOGICO,
    NEGACAO,
    DUPLA_NEGACAO,
    ESPECIAL,
    EOF,
    ERROR,
    
}
